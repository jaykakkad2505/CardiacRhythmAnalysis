Cardiac Rhythm Analysis System
================================
ECG Signal Analysis & Monitoring - a desktop application for importing,
visualizing, and reporting on ECG waveform data, built for structured
clinical review. Rebuilt to match the architecture spec you shared
(MySQL, bcrypt, rule-based Medical Rule Engine, ReportLab PDF reports).

SETUP
1. Install Python dependencies:
     pip install -r requirements.txt

2. Have a MySQL (or MariaDB) server running. If you don't have one yet:
   - Easiest: install XAMPP and start its MySQL service, OR
   - Install MySQL Community Server / MariaDB directly

3. Tell the app how to reach your server. Either edit config.py directly,
   or set environment variables before running:
     CRA_DB_HOST      (default: localhost)
     CRA_DB_PORT      (default: 3306)
     CRA_DB_USER      (default: root)
     CRA_DB_PASSWORD  (default: empty)
     CRA_DB_NAME      (default: cardiac_rhythm_analysis)

   The app creates the database and all tables automatically on first
   run - you don't need to run any SQL yourself.

   NOTE: some fresh MySQL/MariaDB installs default new accounts to an
   auth plugin PyMySQL can't use. If you get an "Access denied" or
   "auth plugin" error on first run, from a MySQL prompt run:
     ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '';
     FLUSH PRIVILEGES;

4. Run the app:
     python main.py

5. First screen is Sign In - click "Create one" to register a clinician
   account, then sign in.

WORKFLOW (matches your Frontend Workflow spec)
Login -> Dashboard -> Patient Management -> Import ECG Dataset ->
Analysis -> Summary -> Generate PDF Report -> (saved to) Report History

THE MEDICAL RULE ENGINE (utils/ecg_processing.py)
This is the core change from the previous ML-based build: instead of an
Isolation Forest flagging individual beats, the app now:
  1. Cleans the signal and detects R-peaks (NeuroKit2)
  2. Delineates P, QRS, and T wave boundaries per beat (NeuroKit2,
     'prominence' method - gives realistic interval lengths)
  3. Calculates Heart Rate, RR, PR, QRS, QT, and QTc (Bazett-corrected)
  4. Compares each parameter against fixed clinical thresholds
     (config.py -> NORMAL_RANGES)
  5. Produces a plain-language finding ("Normal sinus rhythm", "Sinus
     tachycardia", etc.) and a status ("Stable" / "Review needed")

This is genuine signal processing, not a lookup table - the intervals
are measured from the actual waveform you import.

WHAT'S FULLY BUILT AND TESTED
- MySQL storage via PyMySQL (Users, Patients, ECG Reports, Report History)
- bcrypt password hashing
- Full workflow: Login/Register, Dashboard, Patient Management (add,
  edit, delete, search), Import ECG Dataset, Analysis (waveform + R-peak
  plot + pipeline checklist), Summary (parameters + finding + clinician
  notes), PDF report generation matching your mockup layout, Report
  History (search, status filter, preview, status override, delete),
  Settings (edit name, change password, database backup/export, log out
  with confirmation dialog matching your mockup)
- Sample ECG files in sample_data/ for testing without real data

WHAT'S DIFFERENT FROM THE SPEC / DEFERRED (being upfront about this)
- Charts use Matplotlib embedded in the Qt window, not PyQtGraph. Both
  produce interactive-looking charts; swapping to PyQtGraph is a real
  rework of every chart in the app and hasn't been done yet.
- No Qt Material styling library - the same dark navy + red theme is
  hand-built via Qt stylesheets (theme.py), which is why it already
  looks close to your mockups without that dependency.
- Settings' "Dark mode" toggle is present but inert (app is always
  dark) - a real light theme is a separate, sizeable piece of work.
  This was explicitly your own "Future Scope" slide's territory
  (multi-user roles, cloud sync, etc.) so it's flagged rather than
  rushed.
- "Backup Database" / "Export Database" write a plain SQL-statement
  dump of every table (works anywhere), rather than shelling out to
  mysqldump specifically - more portable, same practical result.
- Devices / Alerts pages shown in some of your other mockup slides
  aren't built - they weren't described in enough detail to implement
  confidently, and weren't part of the core Login -> ... -> History
  workflow slide.

FOLDER STRUCTURE (matches your spec)
CardiacRhythmAnalysis/
  assets/            icons
  database/          connection.py, users.py, patients.py, reports.py
  reports/           report_generator.py (PDF)
  ui/                every screen (login, register, dashboard, patients,
                      import_ecg, analysis, summary, report_history,
                      settings) + sliding_stack.py (page-swipe animation)
  utils/             ecg_processing.py (Medical Rule Engine),
                      session.py (in-progress workflow state)
  sample_data/       two ready-made ECG CSVs to test with
  config.py           DB connection + clinical thresholds
  main.py             entry point
  theme.py            Qt stylesheet
  auth_window.py       hosts Sign In / Create Account
